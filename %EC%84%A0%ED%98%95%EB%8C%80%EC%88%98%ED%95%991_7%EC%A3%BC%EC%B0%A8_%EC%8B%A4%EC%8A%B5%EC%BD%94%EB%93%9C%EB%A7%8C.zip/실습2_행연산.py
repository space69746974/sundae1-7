from fractions import Fraction

def print_matrix(matrix):
    for row in matrix:
        print("[" + " ".join(f"{str(v):>6}" for v in row[:-1]) + " | " + str(row[-1]) + "]")
    print()

M = [
    [Fraction(1), Fraction(-2), Fraction(4), Fraction(0)],
    [Fraction(0), Fraction(2), Fraction(-8), Fraction(8)],
    [Fraction(4), Fraction(5), Fraction(8), Fraction(-31)],
]
print("초기 첨가행렬")
print_matrix(M)

# R3 <- R3 - 4R1
M[2] = [M[2][j] - 4 * M[0][j] for j in range(4)]
print("R3 <- R3 - 4R1")
print_matrix(M)

# R2 <- R2 / 2
M[1] = [v / 2 for v in M[1]]
print("R2 <- R2 / 2")
print_matrix(M)

# R3 <- R3 + 3R2
M[2] = [M[2][j] + 3 * M[1][j] for j in range(4)]
print("R3 <- R3 + 3R2")
print_matrix(M)
