from fractions import Fraction

def print_matrix(matrix):
    for row in matrix:
        print("[" + " ".join(f"{str(v):>6}" for v in row[:-1]) + " | " + str(row[-1]) + "]")
    print()

# 첨가행렬
M = [
    [Fraction(1), Fraction(-2), Fraction(1), Fraction(0)],
    [Fraction(0), Fraction(1), Fraction(-4), Fraction(4)],
    [Fraction(0), Fraction(0), Fraction(1), Fraction(3)],
]

n = len(M)
print("초기 첨가행렬")
print_matrix(M)

for col in range(n):
    pivot_row = next((r for r in range(col, n) if M[r][col] != 0), None)
    if pivot_row is None:
        raise ValueError("유일한 해를 구할 수 없습니다.")
    if pivot_row != col:
        M[col], M[pivot_row] = M[pivot_row], M[col]
    pivot = M[col][col]
    M[col] = [v / pivot for v in M[col]]
    for r in range(n):
        if r != col:
            factor = M[r][col]
            M[r] = [M[r][j] - factor * M[col][j] for j in range(n + 1)]

print("기약 행 사다리꼴")
print_matrix(M)
for i in range(n):
    print(f"x{i+1} = {M[i][-1]}")
