from fractions import Fraction

# LU 분해와 LU = A 확인
A = [
    [Fraction(1), Fraction(2), Fraction(4)],
    [Fraction(2), Fraction(3), Fraction(3)],
    [Fraction(-3), Fraction(-10), Fraction(2)],
]
n = len(A)
U = [row[:] for row in A]
L = [[Fraction(1 if i == j else 0) for j in range(n)] for i in range(n)]

for k in range(n - 1):
    if U[k][k] == 0:
        raise ValueError("피벗이 0이므로 행 교환이 필요합니다.")
    for i in range(k + 1, n):
        multiplier = U[i][k] / U[k][k]
        L[i][k] = multiplier
        U[i] = [U[i][j] - multiplier * U[k][j] for j in range(n)]

LU = [[sum(L[i][k] * U[k][j] for k in range(n)) for j in range(n)] for i in range(n)]

print("A =", A)
print("L =", L)
print("U =", U)
print("LU =", LU)
print("LU = A 확인:", LU == A)
