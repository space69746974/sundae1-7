import numpy as np
import matplotlib.pyplot as plt

# 회전 각도
theta_deg = 60
theta = np.deg2rad(theta_deg)

# 원점을 기준으로 시계 방향 회전하는 행렬
A = np.array([
    [np.cos(theta), np.sin(theta)],
    [-np.sin(theta), np.cos(theta)]
])

# 점들을 열벡터로 저장
P = np.array([
    [1, 1, 2, 2],
    [0, 2, 2, 1]
], dtype=float)

Q = A @ P
np.set_printoptions(precision=4, suppress=True)

print("회전행렬 A:")
print(A)
print("회전 전 점들 P:")
print(P)
print("회전 후 점들 Q:")
print(Q)
print("회전 전 각 점의 거리:", np.linalg.norm(P, axis=0))
print("회전 후 각 점의 거리:", np.linalg.norm(Q, axis=0))

P_closed = np.column_stack((P, P[:, 0]))
Q_closed = np.column_stack((Q, Q[:, 0]))
fig, ax = plt.subplots(figsize=(7, 7))
ax.plot(P_closed[0], P_closed[1], "o-", label="Original")
ax.plot(Q_closed[0], Q_closed[1], "o--", label=f"Rotated {theta_deg} degrees clockwise")
ax.axhline(0, color="gray", linewidth=0.8)
ax.axvline(0, color="gray", linewidth=0.8)
ax.scatter(0, 0, color="black", label="Origin")
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Rotation about the origin")
ax.set_aspect("equal", adjustable="box")
ax.grid(True, alpha=0.3)
ax.legend()
plt.tight_layout()
plt.show()
