from fractions import Fraction

def print_matrix(matrix):
    for row in matrix:
        print("[" + " ".join(f"{str(v):>6}" for v in row) + "]")
    print()

# 강의자료의 행 연산 예제를 첨가행렬 형태로 구현
M = [
    [Fraction(2), Fraction(2), Fraction(4), Fraction(8)],
    [Fraction(5), Fraction(7), Fraction(8), Fraction(7)],
    [Fraction(1), Fraction(2), Fraction(1), Fraction(1)],
]
print("초기 행렬")
print_matrix(M)

# 아래쪽 원소를 소거하는 가우스 소거법
n = len(M)
for col in range(min(n, len(M[0]) - 1)):
    pivot_row = next((r for r in range(col, n) if M[r][col] != 0), None)
    if pivot_row is None:
        continue
    M[col], M[pivot_row] = M[pivot_row], M[col]
    for r in range(col + 1, n):
        if M[r][col] != 0:
            factor = M[r][col] / M[col][col]
            M[r] = [M[r][j] - factor * M[col][j] for j in range(len(M[0]))]
            print(f"R{r+1} <- R{r+1} - ({factor})R{col+1}")
            print_matrix(M)

print("행 사다리꼴 행렬")
print_matrix(M)
